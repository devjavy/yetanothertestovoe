# Binance Price Tracker

---

Тестовое задание. Комментарии оставил на русском, но вообще обычно в коде оставляю их на английском. `utils/colorGenerator.ts` и `src/components/Icons.tsx` навайбкожены

Использованы:
* React
* Tailwind
* HeroUI (Tailwind + Framer Motion - зависимости, но ими я и отдельно пользуюсь)
* react-use-websocket
* recharts